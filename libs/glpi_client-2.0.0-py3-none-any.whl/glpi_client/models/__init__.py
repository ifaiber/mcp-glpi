"""
Modelos y estructuras de datos para GLPI Wrapper.
"""

from .enums import SortOrder
from .response import ResponseRange

__all__ = ['SortOrder', 'ResponseRange']